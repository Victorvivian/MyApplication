package com.example.vain.myapplication9;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import java.util.jar.Attributes;

/**
 * Created by Vain on 2018/6/13.
 */

public class MyProvider extends ContentProvider {

    public static final int TABLE_DIR=0;
    public static final int TABLE_ITEM=1;
    private static UriMatcher uriMatcher;
    private MyDatabaseHelper dbHelper;

    static {
        uriMatcher=new UriMatcher(UriMatcher.NO_MATCH);
        uriMatcher.addURI("com.example.Myapplication9.provider","table",TABLE_DIR);
        uriMatcher.addURI("com.example.Myapplication9.provider","table/#",TABLE_ITEM);
    }
    @Override
    public boolean onCreate() {
        dbHelper=new MyDatabaseHelper(getContext(),"Contacter.db",null,1);
        return true;
    }


    @Override
    public Cursor query( Uri uri,  String[] projection, String selection,String[] selectionArgs,
                        String sortOrder) {
        SQLiteDatabase db=dbHelper.getReadableDatabase();
        Cursor cursor=null;
        switch (uriMatcher.match(uri)){
            case TABLE_DIR:
                cursor=db.query("Contacter",projection,selection,selectionArgs,null,null,sortOrder);
                break;
            case TABLE_ITEM:
                cursor=db.query("Contacter",projection,"name=?",new String[]{},null,null,sortOrder);
                break;
            default:
                break;
        }
        return cursor;
    }


    @Override
    public String getType(Uri uri) {
        switch (uriMatcher.match(uri)){
            case TABLE_DIR:
                return "vnd.android.cursor.dir/vnd.com.example.MyApplication9.provider.Contacter";
            case TABLE_ITEM:
                return "vnd.android.cursor.item/vnd.com.example.MyApplication9.provider.Contacter";
        }
        return null;
    }


    @Override
    public Uri insert(Uri uri,ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri,String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update( Uri uri, ContentValues values,  String selection,  String[] selectionArgs) {
        return 0;
    }
}
